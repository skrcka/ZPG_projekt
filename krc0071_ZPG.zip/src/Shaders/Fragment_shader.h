const char *fragment_shader =
		"#version 330\n"
		"out vec4 frag_colour;"
		"void main () {"
		"     frag_colour = vec4 (1, 0.0, 0.5, 1.0);"
		"}";